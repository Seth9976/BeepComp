rm *.msi
